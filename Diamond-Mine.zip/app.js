/* Diamond Mine: self-contained presentation controls. No network or build step. */
(() => {
  'use strict';

  const stage = document.getElementById('stage');
  const slides = Array.from(document.querySelectorAll('#slides > .slide'));
  if (!stage || !slides.length) return;

  const MAIN_SLIDE_COUNT = Math.min(13, slides.length);
  const byId = (id) => document.getElementById(id);
  const dialog = byId('deck-dialog');
  const dialogContent = byId('dialog-content');
  const dialogTitle = byId('dialog-title');
  const previousButton = byId('prev-slide');
  const nextButton = byId('next-slide');
  const stations = Array.from(document.querySelectorAll('.station[data-go]'));
  const controls = {
    overview: byId('overview-toggle'),
    notes: byId('notes-toggle'),
    references: byId('references-toggle'),
    fullscreen: byId('fullscreen-toggle'),
    help: byId('help-toggle'),
  };

  let current = 0;
  let returnFromReferences = 12;
  let dialogMode = null;
  let previousFocus = null;
  let resizeFrame = 0;

  const clamp = (value, minimum, maximum) => Math.max(minimum, Math.min(maximum, value));
  const number = (index) => String(index + 1).padStart(2, '0');

  function readHash() {
    const match = /^#slide-(\d+)$/.exec(window.location.hash);
    return match ? clamp(Number(match[1]) - 1, 0, slides.length - 1) : 0;
  }

  function fitStage() {
    stage.style.setProperty('--scale', Math.min(window.innerWidth / 1600, window.innerHeight / 900));
    resizeFrame = 0;
  }

  function announce(text) {
    const status = byId('live-status');
    if (status) status.textContent = text;
  }

  function setText(id, value) {
    const element = byId(id);
    if (element) element.textContent = value;
  }

  function updateHash(index) {
    const hash = `#slide-${index + 1}`;
    if (window.location.hash === hash) return;
    // replaceState also works from file:// in modern browsers. The fallback
    // preserves navigation if a browser applies a stricter local-file policy.
    try {
      window.history.replaceState(null, '', hash);
    } catch (_) {
      window.location.hash = hash;
    }
  }

  function goToSlide(index, options = {}) {
    const next = clamp(Number(index) || 0, 0, slides.length - 1);
    const old = current;
    if (next >= MAIN_SLIDE_COUNT && old < MAIN_SLIDE_COUNT) returnFromReferences = old;
    current = next;

    if (dialog && dialog.open && !options.keepDialog) closeDialog();
    stage.dataset.direction = next < old ? 'backward' : 'forward';
    stage.dataset.section = slides[next].dataset.section || '';
    stage.dataset.speaker = slides[next].dataset.speaker || '';
    stage.dataset.slide = String(next + 1);

    slides.forEach((slide, slideIndex) => {
      const active = slideIndex === next;
      slide.classList.toggle('is-active', active);
      slide.classList.toggle('is-before', slideIndex < next);
      slide.classList.toggle('is-after', slideIndex > next);
      slide.setAttribute('aria-hidden', String(!active));
      slide.inert = !active;
    });

    const main = next < MAIN_SLIDE_COUNT;
    const progress = main ? next / Math.max(1, MAIN_SLIDE_COUNT - 1) : 1;
    stage.style.setProperty('--progress', String(progress));
    const cart = byId('progress-cart');
    if (cart) cart.style.left = `${progress * 100}%`;
    stations.forEach((station) => {
      const selected = Number(station.dataset.go) === next;
      station.classList.toggle('is-current', selected);
      station.classList.toggle('is-past', Number(station.dataset.go) < next);
      if (selected) station.setAttribute('aria-current', 'step');
      else station.removeAttribute('aria-current');
    });

    setText('section-label', slides[next].dataset.section || (main ? 'Diamond Mine' : 'References'));
    const speaker = slides[next].dataset.speaker;
    setText('speaker-label', speaker ? (/^\d+$/.test(speaker) ? `Speaker ${speaker}` : speaker) : 'Appendix');
    setText('slide-count', main ? `${number(next)} / ${String(MAIN_SLIDE_COUNT).padStart(2, '0')}` : `A${next - MAIN_SLIDE_COUNT + 1} / A${slides.length - MAIN_SLIDE_COUNT}`);
    if (previousButton) previousButton.disabled = next === 0;
    if (nextButton) nextButton.disabled = next === slides.length - 1;
    if (controls.references) controls.references.setAttribute('aria-pressed', String(!main));

    updateHash(next);
    document.title = `${slides[next].dataset.title || 'Diamond Mine'} · Diamond Mine`;
    announce(`${main ? `Slide ${next + 1} of ${MAIN_SLIDE_COUNT}` : `Reference page ${next - MAIN_SLIDE_COUNT + 1}`}. ${slides[next].dataset.title || ''}`);
    document.dispatchEvent(new CustomEvent('slidechange', { detail: { index: next, previous: old, slide: slides[next] } }));
  }

  function closeDialog() {
    if (!dialog || !dialog.open) return;
    dialog.close();
  }

  function makeElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }

  function openDialog(mode, title, content) {
    if (!dialog || !dialogContent || !dialogTitle) return;
    if (dialog.open && dialogMode === mode) {
      closeDialog();
      return;
    }
    if (!dialog.open) previousFocus = document.activeElement;
    dialogMode = mode;
    dialog.dataset.mode = mode;
    dialogTitle.textContent = title;
    dialogContent.replaceChildren(content);
    Object.entries(controls).forEach(([name, control]) => {
      if (control && ['overview', 'notes', 'help'].includes(name)) control.setAttribute('aria-expanded', String(mode === name));
    });
    if (!dialog.open) dialog.showModal();
    const focusTarget = mode === 'overview'
      ? dialogContent.querySelector('[aria-current="page"]')
      : byId('dialog-close');
    if (focusTarget) focusTarget.focus({ preventScroll: true });
  }

  function showOverview() {
    const grid = makeElement('div', 'overview-grid');
    slides.forEach((slide, index) => {
      const button = makeElement('button', 'overview-item');
      button.type = 'button';
      if (index === current) button.setAttribute('aria-current', 'page');
      button.append(
        makeElement('span', 'overview-number', index < MAIN_SLIDE_COUNT ? number(index) : `A${index - MAIN_SLIDE_COUNT + 1}`),
        makeElement('span', 'overview-speaker', index < MAIN_SLIDE_COUNT ? `Speaker ${slide.dataset.speaker || ''}` : 'References'),
        makeElement('span', 'overview-title', slide.dataset.title || `Slide ${index + 1}`),
      );
      button.addEventListener('click', () => goToSlide(index));
      grid.append(button);
    });
    openDialog('overview', 'The mine map', grid);
  }

  function showNotes() {
    const note = (window.DECK_NOTES || [])[current];
    const container = makeElement('div', 'presenter-notes');
    if (typeof note === 'string') {
      note.split(/\n\s*\n/).forEach((paragraph) => container.append(makeElement('p', '', paragraph)));
    } else if (note && typeof note === 'object') {
      if (note.speaker) container.append(makeElement('p', 'notes-speaker', note.speaker));
      if (note.intro) container.append(makeElement('p', '', note.intro));
      const points = note.points || note.notes;
      if (Array.isArray(points)) {
        const list = makeElement('ul', 'notes-list');
        points.forEach((point) => list.append(makeElement('li', '', point)));
        container.append(list);
      } else if (typeof points === 'string') container.append(makeElement('p', '', points));
      if (note.handoff) container.append(makeElement('p', 'notes-handoff', note.handoff));
      if (Array.isArray(note.sources) && note.sources.length) {
        container.append(makeElement('p', 'notes-sources', `Sources: ${note.sources.join('; ')}`));
      }
    } else {
      container.append(makeElement('p', '', current >= MAIN_SLIDE_COUNT ? 'Reference appendix. Use the linked sources for follow-up questions.' : 'No additional presenter notes for this slide.'));
    }
    openDialog('notes', `${number(current)}  ${slides[current].dataset.title || 'Presenter notes'}`, container);
  }

  function showHelp() {
    const list = makeElement('dl', 'shortcuts-list');
    [
      ['→ / Space', 'Next slide'],
      ['←', 'Previous slide'],
      ['Home / End', 'First / last main slide'],
      ['O', 'Open the mine map'],
      ['N', 'Open presenter notes'],
      ['R', 'References / return to your slide'],
      ['F', 'Enter / leave fullscreen'],
      ['?', 'Show keyboard controls'],
      ['Escape', 'Close the current overlay'],
    ].forEach(([key, description]) => list.append(makeElement('dt', '', key), makeElement('dd', '', description)));
    openDialog('help', 'Presentation controls', list);
  }

  function toggleReferences() {
    if (slides.length <= MAIN_SLIDE_COUNT) return;
    goToSlide(current < MAIN_SLIDE_COUNT ? MAIN_SLIDE_COUNT : returnFromReferences);
  }

  async function toggleFullscreen() {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else if (document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen();
      else announce('Fullscreen is unavailable in this browser. Use the browser fullscreen command.');
    } catch (_) {
      announce('Fullscreen could not be entered. Use the browser fullscreen command.');
    }
  }

  previousButton?.addEventListener('click', () => goToSlide(current - 1));
  nextButton?.addEventListener('click', () => goToSlide(current + 1));
  controls.overview?.addEventListener('click', showOverview);
  controls.notes?.addEventListener('click', showNotes);
  controls.references?.addEventListener('click', toggleReferences);
  controls.fullscreen?.addEventListener('click', toggleFullscreen);
  controls.help?.addEventListener('click', showHelp);
  byId('dialog-close')?.addEventListener('click', closeDialog);
  stations.forEach((station) => station.addEventListener('click', () => goToSlide(Number(station.dataset.go))));

  if (dialog) {
    dialog.addEventListener('close', () => {
      dialogMode = null;
      ['overview', 'notes', 'help'].forEach((name) => controls[name]?.setAttribute('aria-expanded', 'false'));
      if (previousFocus instanceof HTMLElement && previousFocus.isConnected && !previousFocus.closest('[inert]')) {
        previousFocus.focus({ preventScroll: true });
      }
      previousFocus = null;
    });
    dialog.addEventListener('click', (event) => {
      if (event.target !== dialog) return;
      const rect = dialog.getBoundingClientRect();
      if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) closeDialog();
    });
  }

  document.addEventListener('keydown', (event) => {
    if (event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey || event.isComposing) return;
    if (event.key === 'Escape') {
      if (dialog?.open) { event.preventDefault(); closeDialog(); }
      return;
    }
    if (dialog?.open) return;
    const target = event.target;
    if (target instanceof Element && target.closest('input, textarea, select, [contenteditable="true"]')) return;
    // Keep native Space activation on controls, while arrow navigation still
    // works after clicking a station, closing notes, or using the mouse arrows.
    if (event.key === ' ' && target instanceof Element && target.closest('button, a, [role="button"]')) return;
    let action;
    switch (event.key) {
      case 'ArrowRight': case ' ': case 'PageDown': action = () => goToSlide(current + 1); break;
      case 'ArrowLeft': case 'PageUp': action = () => goToSlide(current - 1); break;
      case 'Home': action = () => goToSlide(0); break;
      case 'End': action = () => goToSlide(MAIN_SLIDE_COUNT - 1); break;
      case 'o': case 'O': action = showOverview; break;
      case 'n': case 'N': action = showNotes; break;
      case 'r': case 'R': action = toggleReferences; break;
      case 'f': case 'F': action = toggleFullscreen; break;
      case '?': action = showHelp; break;
      default: return;
    }
    event.preventDefault();
    action();
  });

  let touchStart = null;
  stage.addEventListener('touchstart', (event) => {
    if (event.touches.length !== 1 || dialog?.open || event.target.closest('button, a, input, [role="button"]')) return;
    touchStart = { x: event.touches[0].clientX, y: event.touches[0].clientY };
  }, { passive: true });
  stage.addEventListener('touchend', (event) => {
    if (!touchStart || !event.changedTouches.length) return;
    const dx = event.changedTouches[0].clientX - touchStart.x;
    const dy = event.changedTouches[0].clientY - touchStart.y;
    touchStart = null;
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) goToSlide(current + (dx < 0 ? 1 : -1));
  }, { passive: true });
  stage.addEventListener('touchcancel', () => { touchStart = null; }, { passive: true });

  window.addEventListener('resize', () => {
    if (!resizeFrame) resizeFrame = requestAnimationFrame(fitStage);
  });
  window.addEventListener('hashchange', () => goToSlide(readHash()));
  document.addEventListener('fullscreenchange', () => {
    controls.fullscreen?.setAttribute('aria-pressed', String(Boolean(document.fullscreenElement)));
    fitStage();
  });

  fitStage();
  goToSlide(readHash());
})();
